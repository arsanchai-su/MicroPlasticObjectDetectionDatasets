# MicroPlastic > ReLabeling
https://universe.roboflow.com/walailak-university-fearv/microplastic-nuga5

Provided by a Roboflow user
License: BY-NC-SA 4.0

